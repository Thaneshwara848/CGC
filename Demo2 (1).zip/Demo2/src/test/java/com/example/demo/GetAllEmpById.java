package com.example.demo;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.Exceptions.IdNotFoundException;
import com.example.demo.model.Employee;
import com.example.demo.repo.MyRepo;
import com.example.demo.services.MyServices;

@SpringBootTest
public class GetAllEmpById {
	@Mock
    private MyRepo repo;
    

    @InjectMocks
    private MyServices serv;

    @Test
    public void testFetchEmpListById_Success() {
        Employee emp = new Employee(1, "Thanesh", 25, 50000, "Developer");
        when(repo.findById(1)).thenReturn(Optional.of(emp));

        Optional<Employee> result = serv.fetchEmpListById(1);

        assertTrue(result.isPresent());
        assertEquals(emp, result.get());
    }

    @Test
    public void testFetchEmpListById_NotFound() {
        when(repo.findById(1)).thenReturn(Optional.empty());

        Exception exception = assertThrows(IdNotFoundException.class, () -> serv.fetchEmpListById(1));

        assertEquals("Employee with ID 1 not found", exception.getMessage());
    }
}

// covers two key scenarios for the fetchEmpListById service method:
//Successful retrieval of an employee.
//Employee not found, triggering the IdNotFoundException.



//The @Mock annotation is used in unit testing with Mockito to create mock objects. A mock object is a simulated object that mimics the behavior of a real object, allowing you to isolate the class under test and test it independently of its dependencies.


//The @InjectMocks annotation in Mockito is used in unit testing to automatically inject mock objects (created with @Mock) into the class being tested. It simplifies dependency injection by automatically providing mocked dependencies to the class under test
