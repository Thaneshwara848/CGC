package com.example.demo;
import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.Exceptions.IdNotFoundException;
import com.example.demo.repo.MyRepo;
import com.example.demo.services.MyServices;

@SpringBootTest
public class EmployeeControllerTestDeleteEmpById {

    @Mock
    private MyRepo repo;

    @InjectMocks
    private MyServices serv;

    @Test
    public void testDeleteEmpListById_Success() {
        // Mock the repository method to do nothing
        doNothing().when(repo).deleteById(1);

        // Call the service method
        String result = serv.deleteEmpListById(1);

        // Verify the result
        assertEquals("Deleted successfully", result);
        verify(repo, times(1)).deleteById(1);
    }

    @Test
    public void testDeleteEmpListById_NotFound() {
        // Mock the repository to throw an exception
        doThrow(new IdNotFoundException("Employee with ID 1 not found for deletion"))
                .when(repo).deleteById(1);

        // Call the service method and expect exception
        Exception exception = assertThrows(IdNotFoundException.class, () -> serv.deleteEmpListById(1));

        // Verify the exception message
        assertEquals("Employee with ID 1 not found for deletion", exception.getMessage());
        verify(repo, times(1)).deleteById(1);
    }
}
