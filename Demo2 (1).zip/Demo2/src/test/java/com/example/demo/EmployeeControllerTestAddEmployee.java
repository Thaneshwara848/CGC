package com.example.demo;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.mockito.ArgumentMatchers.any;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;

import com.example.demo.controller.MyControler;
import com.example.demo.model.Employee;
import com.example.demo.services.MyServices;

@SpringBootTest
public class EmployeeControllerTestAddEmployee {

    @Autowired
    private MockMvc mockMvc;

    @Mock
    private MyServices serv; // Mock the service

    @InjectMocks
    private MyControler controller; // Inject the mock service into the controller

    @Test
    public void testSaveEmployee_Success() throws Exception {
        // Arrange: Mock the service method to simulate saving an employee
        Employee employee = new Employee(3, "Raj", 30, 60000, "Developer");
        doNothing().when(serv).saveEMployeeToBD(any(Employee.class)); // Mock void method

        // Act: Perform a POST request to add the employee
        ResultActions response = mockMvc.perform(
            post("/addEmployee")
                .contentType("application/json")
                .content("{\"uid\":3, \"name\":\"Raj\", \"age\":30, \"salary\":60000, \"desig\":\"Developer\"}")
        );

        // Assert: Check the response status and headers
        response.andExpect(status().isCreated()) // HTTP 201 Created (for successful resource creation)
                .andExpect(header().string("Location", "/getEmployee/3")); // Assuming /getEmployee/{id} for redirect

        // Verify that the service method was called once
        verify(serv, times(1)).saveEMployeeToBD(any(Employee.class));
    }
}
