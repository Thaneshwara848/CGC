package com.example.demo;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.example.demo.controller.MyControler;
import com.example.demo.model.Employee;
import com.example.demo.services.MyServices;

import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletRequest;

import java.util.Arrays;
import java.util.List;

@SpringBootTest
public class EmployeeControllerTestAddEmpss {

    @InjectMocks
    private MyControler employeeController;

    @Mock
    private MyServices serv;

    private MockMvc mockMvc;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(employeeController).build();
    }

    @Test
    public void testFetchEmpList() throws Exception {
        // Prepare mock data
        Employee emp1 = new Employee(1, "Thanesh", 25, 50000, "Developer");
        Employee emp2 = new Employee(2, "Suresh", 30, 90000, "Manager");
        List<Employee> mockEmployeeList = Arrays.asList(emp1, emp2);

        // Mock the service method call
        when(serv.getEmp()).thenReturn(mockEmployeeList);

        // Perform GET request and verify the response
        mockMvc.perform(get("/getEmployee")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())  // Expect status 200 OK
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$[0].uid").value(1))  // Check id of first employee
                .andExpect(jsonPath("$[0].name").value("Thanesh"))
                .andExpect(jsonPath("$[1].uid").value(2))  // Check id of second employee
                .andExpect(jsonPath("$[1].name").value("Suresh"));

        // Verify that serv.getEmp() was called once
        verify(serv, times(1)).getEmp();
    }
}

