package com.example.demo.controller;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Employee;
import com.example.demo.services.MyServices;

@RestController
public class MyControler {
	
	@Autowired
	private MyServices serv;

	@GetMapping("/getEmployee")
	public List<Employee> fetchEmpList(){ 
		List<Employee> emps=new ArrayList<>();
		 emps =serv.getEmp();
		return emps;
	}
	
	@GetMapping("/getEmployee/{id}")
	public Employee fetchEmpListById(@PathVariable int id) {
	    return serv.fetchEmpListById(id).get();
	}

	
	@PostMapping("/addEmployee")
	public ResponseEntity<Void> saveEmployee(@RequestBody Employee employee) {
	    serv.saveEMployeeToBD(employee); // Save the employee to the database
	    HttpHeaders headers = new HttpHeaders();
	    headers.setLocation(URI.create("/getEmployee")); // Redirect location
	    return new ResponseEntity<>(headers, HttpStatus.FOUND); // 302 Found
	}

	
	@DeleteMapping("/deleteEmployee/{id}")
	public String deleteEmpListByIds(@PathVariable int id){ 
		return serv.deleteEmpListById(id);
	}
	@DeleteMapping("/deleteAllEmployee")
	public String deleteAllEmpList(){ 
		return serv.deleteAllEmpList();
	}
	
	@PutMapping("/updateEmployee")
	public Employee saveorUpdateEmployeeList(@RequestBody Employee employee){ 
		
		return serv.saveEMployeeToBD(employee);
		
	}
}
