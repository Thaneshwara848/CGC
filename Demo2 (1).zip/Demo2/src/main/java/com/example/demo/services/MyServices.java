package com.example.demo.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Exceptions.IdNotFoundException;
import com.example.demo.Exceptions.NORecordsException;
import com.example.demo.model.Employee;
import com.example.demo.repo.MyRepo;

@Service
public class MyServices {

	@Autowired
	private MyRepo repo;
	
	public List<Employee> getEmp()
	{
		return repo.findAll();
	}

//    public Optional<Employee> fetchEmpListById(int id){
//		
//		return repo.findById(id);
//	
//	}
	public Optional<Employee> fetchEmpListById(int id) {
	    return Optional.ofNullable(
	        repo.findById(id)
	            .orElseThrow(() -> new IdNotFoundException("Employee with ID " + id + " not found"))
	    );
	}

    public Employee  saveEMployeeToBD(Employee employee)
	{
		return repo.save(employee);
		
	}
    public String deleteEmpListById(int id) {
        try {
            repo.deleteById(id);
            return "Deleted successfully";
        } catch (IdNotFoundException ex) {
            throw new IdNotFoundException("Employee with ID " + id + " not found for deletion");
        }
    }


//	public String deleteAllEmpList() {
//	repo.deleteAll();
//		return "All record Deleted ...!";
//	}
    public String deleteAllEmpList() {
        if (repo.findAll().isEmpty()) {
            throw new NORecordsException("No records to delete");
        }
        repo.deleteAll();
        return "All records deleted successfully!";
    }


    
    
}
