package com.example.demo.Exceptions;

public class NORecordsException  extends RuntimeException {
    public NORecordsException(String message) {
        super(message);
    }
}