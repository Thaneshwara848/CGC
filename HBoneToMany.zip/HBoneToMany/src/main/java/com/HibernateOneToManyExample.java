package com;


import com.Department;
import com.Employee;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class HibernateOneToManyExample {

    public static void main(String[] args) {
        // Create Hibernate SessionFactory
        SessionFactory factory = new Configuration()
                .configure("hibernate.cfg.xml")
                .addAnnotatedClass(Department.class)
                .addAnnotatedClass(Employee.class)
                .buildSessionFactory();

        // Create a session
    
        Session session = factory.openSession();
        try {
            // Begin transaction
            session.beginTransaction();

            // Create a department
            Department department = new Department();
            department.setName("IT Department");

            // Create employees
            Employee emp1 = new Employee();
            emp1.setName("Alice");
            emp1.setDesignation("Developer");

            Employee emp2 = new Employee();
            emp2.setName("Bob");
            emp2.setDesignation("Tester");

            // Associate employees with the department
            department.addEmployee(emp1);
            department.addEmployee(emp2);

            // Save department (employees will be saved due to CascadeType.ALL)
            session.save(department);

            // Commit transaction
            session.getTransaction().commit();

            System.out.println("Data saved successfully!");
        } finally {
            // Close the factory
            factory.close();
        }
    }
}
