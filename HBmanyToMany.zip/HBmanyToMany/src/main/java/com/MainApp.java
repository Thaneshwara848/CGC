package com;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class MainApp {
    public static void main(String[] args) {
        // Setup Hibernate SessionFactory
        SessionFactory factory = new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();
        Session session = factory.openSession();
        Transaction transaction = session.beginTransaction();

        // Create Students
        Student student1 = new Student("Alice");
        Student student2 = new Student("Bob");

        // Create Courses
        Course course1 = new Course("Mathematics");
        Course course2 = new Course("Physics");

        // Establish Many-to-Many Relationships
        student1.addCourse(course1);
        student1.addCourse(course2);
        student2.addCourse(course1);

        // Save Entities
        session.save(student1);
        session.save(student2);
        session.save(course1);
        session.save(course2);

        // Commit transaction
        transaction.commit();
        session.close();

        System.out.println("Many-to-Many mapping completed!");
    }
}
