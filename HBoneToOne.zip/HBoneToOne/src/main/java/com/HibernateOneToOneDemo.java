package com;


import com.Address;
import com.User;
import com.HibernateUtil;
import org.hibernate.Session;
import org.hibernate.Transaction;

public class HibernateOneToOneDemo {
    public static void main(String[] args) {
        // Create User and Address Objects
        Address address = new Address();
        address.setStreet("456 Main Street");
        address.setCity("Hydrabad");
        address.setState("AP");

        User user = new User();
        user.setName("Sumith");
        user.setAddress(address);

        // Save Data Using Hibernate
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction transaction = session.beginTransaction();

        try {
            session.save(user);
            transaction.commit();
            System.out.println("User and Address saved successfully!");
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        } finally {
            session.close();
        }
    }
}
